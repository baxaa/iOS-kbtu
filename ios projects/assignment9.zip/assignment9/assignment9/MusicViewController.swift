//
//  MusicViewController.swift
//  assignment9
//
//  Created by Baqbergen Onalbekov on 17.11.2024.
//

import UIKit

class MusicViewController: UIViewController {

    @IBOutlet weak var MusicTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        MusicTableView.rowHeight = UITableView.automaticDimension
        MusicTableView.estimatedRowHeight = 150
        MusicTableView.dataSource = self
        MusicTableView.register(MyTableViewCell.nib(), forCellReuseIdentifier: MyTableViewCell.identifier)
    }
}

extension MusicViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == MusicTableView {
            return DataProvider.shared.getItems(for: .music).count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MyTableViewCell.identifier, for: indexPath)as! MyTableViewCell
        print("Configuring cell for row: \(indexPath.row)")
        if tableView == MusicTableView {
            let books = DataProvider.shared.getItems(for: .music)
            cell.myTitle.text = books[indexPath.row].title
        }
        return cell
    }
    
    
}
