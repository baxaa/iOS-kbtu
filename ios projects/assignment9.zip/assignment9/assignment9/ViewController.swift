//
//  ViewController.swift
//  assignment9
//
//  Created by Baqbergen Onalbekov on 17.11.2024.
//

import UIKit



class ViewController: UIViewController {
    

    @IBOutlet weak var MovieTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        MovieTableView.rowHeight = UITableView.automaticDimension
        MovieTableView.estimatedRowHeight = 150
        MovieTableView.dataSource = self
        MovieTableView.isScrollEnabled = true
        MovieTableView.isUserInteractionEnabled = true
        MovieTableView.register(MyTableViewCell.nib(), forCellReuseIdentifier: MyTableViewCell.identifier)
        
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        if let vc = storyBoard.instantiateViewController(withIdentifier: "detailView") as? DetailViewController {
            
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == MovieTableView {
            return DataProvider.shared.getItems(for: .movies).count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MyTableViewCell.identifier, for: indexPath)as! MyTableViewCell
        print("Configuring cell for row: \(indexPath.row)")
        if tableView == MovieTableView {
            let books = DataProvider.shared.getItems(for: .movies)
            cell.myTitle.text = books[indexPath.row].title
        }
        return cell
    }
    
}

